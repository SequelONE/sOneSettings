<?php

$_lang['area_sonesettings_main'] = 'Основные';

$_lang['setting_sonesettings_some_setting'] = 'Какая-то настройка';
$_lang['setting_sonesettings_some_setting_desc'] = 'Это описание для какой-то настройки';