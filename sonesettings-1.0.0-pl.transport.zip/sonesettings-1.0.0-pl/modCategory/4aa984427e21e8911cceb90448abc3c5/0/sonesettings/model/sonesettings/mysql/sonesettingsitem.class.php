<?php
require_once (dirname(__DIR__) . '/sonesettingsitem.class.php');
class sOneSettingsItem_mysql extends sOneSettingsItem {}