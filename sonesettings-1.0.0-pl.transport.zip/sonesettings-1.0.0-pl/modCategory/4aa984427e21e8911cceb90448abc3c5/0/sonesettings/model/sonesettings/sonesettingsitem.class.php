<?php

/**
 * @package sonesettings
 */
class sOneSettingsItem extends xPDOSimpleObject
{
}